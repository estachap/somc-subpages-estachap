somc-subpages-estachap
======================

Wordpress 3.5 plugin used to display all subpages it is placed on.

An object­oriented Wordpress 3.5+ Plugin called “somc­subpages­<yourgithubname>” that can be used as a Wordpress Widget and as a Wordpress Shortcode (naming convention: [somc­subpages­<yourgithubname>]). It should display
all subpages of the page it is placed on.

It fetchs and displays all subpages' titles, truncated after 20 characters and (if present) it shows a very small thumbnail­version of the pages/posts 'featured image' next to the title. Each level can be sorted by title in ascending and descending order by the user. It should also be possible expand and collapsed each level. All this must be possible without reconnecting to the server after the page has been loaded.
